﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;

namespace XAML_Esempio_Falghera
{
    /// <summary>
    /// Logica di interazione per MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Button b;
        public MainWindow()
        {
            InitializeComponent();
            btnOra.Click += new RoutedEventHandler(CheOreSono); //sottoscrizione ad evento da codice
        }

        private void CheOreSono(object sender, RoutedEventArgs e)
        {
            DateTime data = DateTime.Now;
            MessageBox.Show($"Sono le ore {data.Hour}:{data.Minute}"); //al click del bottone, verrà visualizzata l'ora di oggi
        }

        private void ProvaClick(object sender, RoutedEventArgs e)
        {
            if (sender == btnProva1) //se il bottone 1 è stato cliccato
                MessageBox.Show("Hai cliccato il bottone 1!");
            else if (sender == btnProva2) //se il bottone 2 è stato cliccato
                MessageBox.Show("Hai cliccato il bottone 2!");
        }

        private void Button_MouseUp(object sender, MouseButtonEventArgs e)
        {
            //scrivo la posizione nella quale è stato cliccato il bottone più grande
            MessageBox.Show($"Hai cliccato il bottone in posizione {e.GetPosition(this).ToString()}");
        }

        private void CreaBottone(object sender, RoutedEventArgs e)
        {
            b = new Button(); //istanzio un oggetto Bottone
            //imposto contenuto e dimensioni
            b.Content = "Bottone creato da codice";
            b.Width = 200;
            b.Height = 40;
            b.Click += new RoutedEventHandler(EliminaClick); //associo un evento click
            gd.Children.Add(b); //aggiungo il bottone dalla grid
            btnCrea.IsEnabled = false;
        }

        private void EliminaClick(object sender, RoutedEventArgs e)
        {
            gd.Children.Remove(b); //rimuovo il bottone dalla grid
        }
    }
}
